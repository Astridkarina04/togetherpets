document.addEventListener('DOMContentLoaded', function() {
    // Asegúrate de que los IDs sean correctos y coincidan con los que tienes en el HTML
    var solictInfoBtn = document.getElementById('setNot1');
    var notiInfoBtn = document.getElementById('setNot2'); // Aquí cambiamos el id a setNot2

    // Al hacer clic en el botón de solicitud
    solictInfoBtn.addEventListener('click', function() {
        alert('Se solicitó la historia clínica');
    });

    // Al hacer clic en el botón de notificación
    notiInfoBtn.addEventListener('click', function() {
        alert('Te notificaremos');
    });
});