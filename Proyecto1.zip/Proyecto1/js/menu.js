// Obtener los elementos del DOM para el menú (abrir y cerrar)
const openMenu = document.querySelector("#open-menu");
const closeMenu = document.querySelector("#close-menu");
const aside = document.querySelector("aside");

// Evento para abrir el menú en pantallas móviles
openMenu.addEventListener("click", () => {
    aside.classList.add("aside-visible");
});

// Evento para cerrar el menú en pantallas móviles
closeMenu.addEventListener("click", () => {
    aside.classList.remove("aside-visible");
});

// Obtener los elementos del DOM para los filtros y productos
const botonTodos = document.getElementById('todos');
const botonPerros = document.getElementById('perros');
const botonGatos = document.getElementById('gatos');
const filtroTamano = document.getElementById('filtro-tamano');
const filtroSexo = document.getElementById('filtro-sexo');
const contenedorProductos = document.getElementById('contenedor-productos');

// Variables de estado
let categoriaActual = 'todos'; // Por defecto, todos los productos

// Escuchar eventos de los botones del menú
botonTodos.addEventListener('click', () => {
    categoriaActual = 'todos';
    actualizarFiltros();
    activarBoton(botonTodos);  // Activar botón 'Todos'
});

botonPerros.addEventListener('click', () => {
    categoriaActual = 'perros';
    actualizarFiltros();
    activarBoton(botonPerros);  // Activar botón 'Perros'
});

botonGatos.addEventListener('click', () => {
    categoriaActual = 'gatos';
    actualizarFiltros();
    activarBoton(botonGatos);  // Activar botón 'Gatos'
});

// Escuchar eventos de los filtros
filtroTamano.addEventListener('change', actualizarFiltros);
filtroSexo.addEventListener('change', actualizarFiltros);

// Función para activar el botón seleccionado del menú
function activarBoton(botonSeleccionado) {
    const botones = document.querySelectorAll('.boton-menu');
    botones.forEach(boton => boton.classList.remove('active'));
    botonSeleccionado.classList.add('active');
}

// Función que aplica los filtros
function actualizarFiltros() {
    const productos = document.querySelectorAll('.producto');
    const tamanoSeleccionado = filtroTamano.value;
    const sexoSeleccionado = filtroSexo.value;

    productos.forEach(producto => {
        const esPerro = producto.classList.contains('perro');
        const esGato = producto.classList.contains('gato');
        const tamanoProducto = producto.getAttribute('data-tamano');
        const sexoProducto = producto.getAttribute('data-sexo');

        let mostrarProducto = true;

        // Filtrado por categoría (perros, gatos, todos)
        if (categoriaActual === 'perros' && !esPerro) {
            mostrarProducto = false;
        } else if (categoriaActual === 'gatos' && !esGato) {
            mostrarProducto = false;
        }

        // Filtrado por tamaño
        if (tamanoSeleccionado !== 'todos' && tamanoSeleccionado !== tamanoProducto) {
            mostrarProducto = false;
        }

        // Filtrado por sexo
        if (sexoSeleccionado !== 'todos' && sexoSeleccionado !== sexoProducto) {
            mostrarProducto = false;
        }

        // Mostrar u ocultar producto
        producto.style.display = mostrarProducto ? 'block' : 'none';
    });

    // Actualizar visibilidad de los filtros según la categoría
    if (categoriaActual === 'gatos') {
        filtroTamano.disabled = true;  // Desactivar filtro tamaño en la categoría gatos
    } else {
        filtroTamano.disabled = false;  // Activar filtro tamaño en las demás categorías
    }
}

// Inicializar
actualizarFiltros();