// Datos de las noticias con categorías
const noticiasData = [
    {
        title: "¡Gato Atropellado se Recupera Gracias a una Compleja Cirugía!",
        image: "../img/Noticias/not4.jpg",
        category: "rescates",
        description: "Nos alegra informar que el valiente gatito, que fue atropellado en una calle de la ciudad, está en proceso de recuperación tras una cirugía exitosa realizada por el equipo veterinario de Together Pets.",
        url: "#"
    },
    {
        title: "¡Perro Perdido Reencuentra a Su Familia Después de Dos Años!",
        image: "../img/Noticias/not10.webp",
        category: "mascotaE",
        description: "Nos llena de alegría compartir la emotiva historia del reencuentro de un perro perdido con su familia después de dos años. Together Pets tuvo el honor de ser parte de este conmovedor momento.",
        url: "#"
    },
    {
        title: "¡Perro perdido por los lados de la plaza de paloquemado!",
        image: "../img/Noticias/not11.jfif",
        category: "mascotaP",
        description: "Alaska una perrita criolla se perdió el pasado día 10 de agosto por la plaza de paloquemado. Cualquier información comunicarse a los siguientes números...",
        url: "#"
    },
    {
        title: "¡Veterinario Viaja a Zonas Rurales para Brindar Atención Gratuita a Animales!",
        image: "../img/Noticias/not12.png",
        category: "educación",
        description: "En una destacada iniciativa para apoyar a comunidades rurales, Together Pets ha enviado a un veterinario experimentado para proporcionar atención médica gratuita a animales en zonas alejadas.",
        url: "#"
    },
    {
        title: "¡Veterinarios en Acción: Operación Gratuita para Mascotas de Familias de Bajos Recursos!",
        image: "../img/Noticias/not7.jpg",
        category: "educación",
        description: "Nos complace anunciar que Together Pets, en colaboración con veterinarios voluntarios, ha llevado a cabo una operación gratuita para mascotas de familias de bajos recursos.",
        url: "#"
    }
];

// Función para mostrar noticias filtradas
function displayNoticias(filtradas) {
    const container = document.querySelector(".container-card");
    container.innerHTML = "";  // Limpiar contenedor de noticias

    filtradas.forEach(noticia => {
        const card = document.createElement("div");
        card.className = "card";

        const figure = document.createElement("figure");
        const img = document.createElement("img");
        img.src = noticia.image;
        img.alt = noticia.category;
        figure.appendChild(img);

        const contenidoCard = document.createElement("div");
        contenidoCard.className = "contenido-card";

        const h3 = document.createElement("h3");
        h3.textContent = noticia.title;

        const p = document.createElement("p");
        p.textContent = noticia.description;

        const a = document.createElement("a");
        a.href = noticia.url;
        a.textContent = "Leer más";

        contenidoCard.appendChild(h3);
        contenidoCard.appendChild(p);
        contenidoCard.appendChild(a);

        card.appendChild(figure);
        card.appendChild(contenidoCard);

        container.appendChild(card);
    });
}

// Función para filtrar noticias por categoría
function buscar(cat) {
    if (cat === "todos") {
        displayNoticias(noticiasData);  // Mostrar todas las noticias
    } else {
        const filtradas = noticiasData.filter(noticia => noticia.category === cat);
        displayNoticias(filtradas);  // Mostrar solo las noticias filtradas por categoría
    }
}

// Función para buscar noticias por palabra clave
function buscarTema() {
    const input = document.querySelector("#busqueda").value.toLowerCase();
    const filtradas = noticiasData.filter(noticia => noticia.title.toLowerCase().includes(input));
    displayNoticias(filtradas);
}

// Cargar todas las noticias al inicio
document.addEventListener("DOMContentLoaded", () => {
    buscar("todos");
});
