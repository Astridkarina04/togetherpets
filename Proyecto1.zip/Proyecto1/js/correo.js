const btn = document.getElementById('button');

document.getElementById('form').addEventListener('submit', function(event) {
  event.preventDefault();

  const emailInput = this.email.value; // Suponiendo que el input de email tiene el nombre 'email'

  // Validar que el correo contenga un arroba
  if (!emailInput.includes('@')) {
    alert('Por favor, ingresa una dirección de correo electrónico válida.');
    return;
  }

  btn.value = 'Enviando...';

  const serviceID = 'default_service';
  const templateID = 'template_dt7uu1f';

  emailjs.sendForm(serviceID, templateID, this)
    .then(() => {
      btn.value = 'Enviar';
      alert('¡Correo enviado!');
    }, (err) => {
      btn.value = 'Send Email';
      alert('Error al enviar el correo: ' + JSON.stringify(err));
    });
});