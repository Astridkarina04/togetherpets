<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-UA-Compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <title>complete responsive mark express</title>
    <link rel="stylesheet" href="../css/Indexf.css">
</head>
<body>
    <header class="header">
        <div class="logo">
            <img src="../img/Logo_con_letras-removebg-preview.png" alt="logo de la marca">
        </div>
        <nav>
			<ul class="nav-links">
                <li><a class="active" href="../usuario/index.php">Inicio</a></li>
                <li><a href="../usuario/peluditos.php">Peluditos</a></li>
                <li><a href="../usuario/Noticias.php">Noticias</a></li>
                <li><a href="../usuario/comoadoptar.html">¿Cómo adoptar?</a></li>
            </ul>
        </nav>
        <div class="header-actions">
            <div class="profile-menu">
                <span class="profile-name">Astrid Karina</span>
                <img src="../img/Nina.PNG" alt="Perfil" class="profile-img">
                <div class="dropdown-content">
                    <a href="../Vista/exito.php">Perfil</a>
                    <a href="../vista/logout.php">Cerrar sesión</a>
                </div>
            </div>
        </div>        
    </header>
    <!-- SCRIPT FOTO DE PERFIL -->
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const profileMenu = document.querySelector('.profile-menu');
            const dropdownContent = document.querySelector('.dropdown-content');
    
            // Verificar si los elementos existen
            if (profileMenu && dropdownContent) {
                profileMenu.addEventListener('click', function(event) {
                    // Evitar que el evento de clic se propague a otros elementos
                    event.stopPropagation();
                    
                    // Toggle entre mostrar y ocultar el menú
                    if (dropdownContent.style.display === 'block') {
                        dropdownContent.style.display = 'none';
                    } else {
                        dropdownContent.style.display = 'block';
                    }
                });
    
                // Ocultar el menú si se hace clic fuera de él
                document.addEventListener('click', function(event) {
                    if (!profileMenu.contains(event.target) && !dropdownContent.contains(event.target)) {
                        dropdownContent.style.display = 'none';
                    }
                });
            }
        });
    </script>
    <!--CONTENIDO INDEX-->
    <section></section>
		<div class="contenedor">
		<div class="seccion1">
			<h1 class="recto">Union con una patita</h>
			<h2><span class='supermercado'>TogueterPets</span></h2>
			<p>Bienvenida</p>
			<p>Lista para un amigo</p>
		</div>
		<div class="seccion2"></div>
		</div>
	</section>
	<!--Noticias-->
			<section class="container top-noticias">
					<br><h1 class="heading-1">NOTICIAS MÁS RECIENTES</h1>
					<div class="container-noticias">
						<div class="card-not not-noticias">
							<img src="../img/Noticias/not1.png">
							<p>Adopciones abiertas</p>
							<a href=".not.html"><span>Ver más</span></a>
						</div>
						<div class="card-not not-noticias2">
							<img src="../img/Noticias/not2.png">
							<p>Evento de Recaudación</p>
							<a href="not2.html"><span>Ver más</span></a>
						</div>
						<div class="card-not not-noticias3">
							<img src="../img/Noticias/not3.png">
							<p>Nuevo Refugio</p>
							<a href="not3.html"><span>Ver más</span></a>
						</div>
					</div>
				</section>
			</P>
			<!--Patrocinadores-->
			<section class="container top-patrocinadores">
				<br>
				<h1 class="heading-1">PATROCINADORES</h1>
	<br>
				<div class="container-patrocinadores">
				
					<div class="card-patrocinadores">
						<div id="setTex1" class="container-img">
							<img src="../img/Patrocinadores/logo1.jpg"/> 
						</div>
						<div class="content-card-patrocinadores"> 
							
							<h3>Muebles para mascotas y suplementos nutricionales.</h3>
						
							<p class="price">Furry Friends Haven</p>
						
						</div>
					</div>
					
					<div class="card-patrocinadores">
						<div id="setTex2" class="container-img">
							<img src="../img/Patrocinadores/logo2.png"/>
							
						</div>
						<div class="content-card-patrocinadores" >
							
							<h3>Juguetes interactivos y camas de lujo para gatos.</h3>
						
							<p class="price">Whisker Wonders</p>
						</div>
					</div>
	
					
					<div class="card-patrocinadores">
						<div  id="setTex3" class="container-img">
							<img src="../img/Patrocinadores/logo3.jpg"/>
							
							
						</div>
						<div class="content-card-patrocinadores" id="setTex1" >
							
							<h3>Golosinas saludables y ropa para perros.</h3>
						
							<p class="price">Bark & Co</p>
						</div>
					</div>
					
					<div class="card-patrocinadores">
						<div  id="setTex4" class="container-img">
							<img src="../img/Patrocinadores/logo4.jpg"/>
							
						</div>
						<div class="content-card-patrocinadores"  >
							
							<h3>Comida premium para perros y gatos.</h3>
						
							<p class="price">Pawfect Pet Supplies</p>
						</div>
					</div>
					<div class="card-patrocinadores">
						<div  id="setTex5" class="container-img">
							<img src="../img/Patrocinadores/logo5.png"/>
							
						</div>
						<div class="content-card-patrocinadores"  >
							
							<h3>Insumos de asea para mascotas.</h3>
						
							<p class="price">EcoPet</p>
						</div>
					</div>
					<div class="card-patrocinadores">
						<div  id="setTex6" class="container-img">
							<img src="../img/Patrocinadores/logo6.png"/>
							
						</div>
						<div class="content-card-patrocinadores"  >
							
							<h3>Ropa y accesorios para mascotas.</h3>
						
							<p class="price">Fashion husky</p>
						</div>
					</div>
				</div>
			</section>
	<p>
			<br>
			<br>
			<br>
			<br><h1 class="heading-1">¿ESTÁS INTERESADO EN SER PATROCINADOR?</h1>
			<br>
			<br>
			<section class="banner2">
				
				<br>
				<div class="content-banner2">
					<h2> <br>Conviértete en un guardián de estos peluditos </h2>
					<h2> <br> </h2>
					<input type="email" placeholder="Ingresa el correo aquí..."><button id="setBtn"class="btn-primary mt-2">Enviar</button>
					
				</div>
			</section>
	<br>
				<section class="container eventos">
					<h1 class="heading-1">PRÓXIMOS EVENTOS</h1>
	
					<div class="container-eventos">
						<div class="card-evento">
							<div class="container-img">
								<img src="../img/adopcion.png" />
								
							</div>
							<div class="content-evento">
								<h3>Jornada de Adopción</h3>
								<span>10 Agosto 2024</span>
								<p>
									Únete a nosotros el próximo sábado en el parque central para una jornada de adopción, ven y adopta un angles de 4 patas.
								</p>
								<div id="setNot1"class="btn-read-more">Notificar</div>
							</div>
						</div>
						<div class="card-evento">
							<div class="container-img">
								<img src="../img/esteril.jpg"/>
								
							</div>
							<div class="content-evento">
								<h3>Campaña de Esterilización</h3>
								<span>15 Septiembre 2024</span>
								<p>
									El próximo mes ofreceremos servicios de esterilización a bajo costo para mascotas de la comunidad. ¡No te lo pierdas!
								</p>
								<div id="setNot2" class="btn-read-more">Notificar</div>
							</div>
						</div>
						<div class="card-evento">
							<div class="container-img">
								<img src="../img/cuidado.jpg">
								
							</div>
							<div class="content-evento">
								<h3>Taller de Cuidado Animal</h3>
								<span>10 Noviembre 2024</span>
								<p>
									Antes de las fiestas decembrinas, te invitamos a nuestro taller gratuito sobre recomendaciones para el cuidado y bienestar animal.							</p>
								<div id="setNot3"class="btn-read-more">Notificar</div>
							</div>
						</div>
					</div>
				</section>
			</main>
	<br>
			<footer class="footer">
				<div class="container container-footer">
					<div class="footer-section logo">
						<img src="../img/Logo_con_letras_claro-removebg-preview.png" alt="Logo" class="logo-img">
					</div>
				</div>
				<br>
				<div class="copyright">
					<p>Proyecto de Adopción y Bienestar Animal Together Pets &copy; 2024</p>
				</div>
			</footer>
			<script src="../js/scri.js"></script>
        </div>
    </section>
</body>
</html>
