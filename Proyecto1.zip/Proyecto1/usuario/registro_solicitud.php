<?php
include("conexion.php");

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nombre = $_POST['nombre'];
    $apellido = $_POST['apellido'];
    $edad = $_POST['edad'];
    $nombre_animal = $_POST['nombre_animal'];
    $fecha_solicitud = $_POST['fecha_solicitud'];

    // Insertar datos en la tabla solicitudes
    $sql = "INSERT INTO solicitudes (nombre, apellido, edad, nombre_animal, fecha_solicitud) 
            VALUES (:nombre, :apellido, :edad, :nombre_animal, :fecha_solicitud)";
    
    $stmt = $conexion->prepare($sql);
    $stmt->bindParam(':nombre', $nombre);
    $stmt->bindParam(':apellido', $apellido);
    $stmt->bindParam(':edad', $edad);
    $stmt->bindParam(':nombre_animal', $nombre_animal);
    $stmt->bindParam(':fecha_solicitud', $fecha_solicitud);

    if ($stmt->execute()) {
        echo "Solicitud registrada con éxito.";
    } else {
        echo "Error al registrar la solicitud.";
    }
}
?>
