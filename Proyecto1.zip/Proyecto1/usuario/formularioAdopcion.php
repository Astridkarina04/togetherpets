<?php
// Incluir archivo de conexión a la base de datos
include("conex.php");

// Obtener los datos de los animales desde la base de datos
$sql = "SELECT id_animal, nombre, especie, edad, sexo FROM animales";
$result = $conexion->query($sql);
$animals = $result->fetchAll(PDO::FETCH_ASSOC); // Obtener todos los datos de los animales
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulario de Solicitud</title>
    <link rel="stylesheet" href="../css/FAdopcion.css"> <!-- Asegúrate de enlazar tu archivo CSS -->
</head>
<body>
    <!-- Encabezado -->
    <header class="header">
            <div class="logo">
                    <img src="../img/Logo_con_letras-removebg-preview.png" alt="logo de la marca">
                </div>
                <nav>
                    <ul class="nav-links">
                        <li><a class="active" href="../usuario/index.php">Inicio</a></li>
                        <li><a href="../usuario/peluditos.php">Peluditos</a></li>
                        <li><a href="../usuario/Noticias.php">Noticias</a></li>
                        <li><a href="../usuario/comoadoptar.html">¿Cómo adoptar?</a></li>
                    </ul>
                </nav>
                <div class="header-actions">
                    <div class="profile-menu">
                        <span class="profile-name">Astrid Karina</span>
                        <img src="../img/Nina.PNG" alt="Perfil" class="profile-img">
                        <div class="dropdown-content">
                            <a href="../Vista/exito.php">Perfil</a>
                            <a href="../vista/logout.php">Cerrar sesión</a>
                        </div>
            </div>
        </div>
    </header>
    
    <section class="form-register">
        <h4>Formulario de solicitud</h4>
        <form id="solicitudForm" action="../usuario/index.php" method="POST">
            <div class="form-container">
                <div class="form-column">
                    <!-- Nombre del Animal -->
                    <label for="nombre_animal">Nombre del Animal:</label>
                    <select  class="controls" name="nombre_animal" id="nombre_animal">
                        <?php
                        // Llenar las opciones del select con los animales obtenidos de la base de datos
                        foreach ($animals as $animal) {
                            echo "<option value='" . $animal['id_animal'] . "'>" . $animal['nombre'] . " </option>";
                        }
                        ?>
                    </select><br>

                    <!-- Edad del Animal -->
                    <label for="animal_edad">Edad del Animal:</label>
                    <input  class="controls" type="text" name="animal_edad" id="animal_edad" value="<?php $valor; ?>" readonly><br>

                    <!-- Especie del Animal -->
                    <label for="animal_especie">Especie del Animal:</label>
                    <input  class="controls" type="text" name="animal_especie" id="animal_especie" readonly><br>

                    <!-- Sexo del Animal -->
                    <label for="animal_sexo">Sexo del Animal:</label>
                    <input   class="controls" type="text" name="animal_sexo" id="animal_sexo" readonly><br>
                </div>
                <div>

                    <!-- Datos del Solicitante -->
                    <label for="nombre">Nombre:</label>
                    <input class="controls" type="text" name="nombre" id="nombre" placeholder="" required value="<?php echo isset($usuario['nombre']) ? $usuario['nombre'] : ''; ?>"><br>

                    <label for="apellido">Apellido:</label>
                    <input class="controls" type="text" name="apellido" id="apellido" required value="<?php echo isset($usuario['apellido']) ? $usuario['apellido'] : ''; ?>"><br>

                    <label for="edad">Edad:</label>
                    <input  class="controls" type="number" name="edad" id="edad" required><br><br>

                    <!-- Fecha de Solicitud -->
                    <input  class="controls" type="hidden" name="fecha_solicitud" value="<?php echo date('Y-m-d'); ?>">

                    <button class="botons" type="submit">Enviar Solicitud</button>
                </form>
            </div>
        
        <script>
            // Crear un objeto que contenga todos los animales y sus datos
            var animals = <?php echo json_encode($animals); ?>;

            // Script para actualizar los datos del animal seleccionado
            document.getElementById('nombre_animal').addEventListener('change', function() {
                var selectedAnimalId = this.value;

                // Encontrar el animal seleccionado por su id
                var selectedAnimal = animals.find(function(animal) {
                    return animal.id_animal == selectedAnimalId;
                });

                // Si se encontró el animal, actualizar los campos correspondientes
                if (selectedAnimal) {
                    document.getElementById('animal_edad').value = selectedAnimal.edad;
                    document.getElementById('animal_especie').value = selectedAnimal.especie;
                    document.getElementById('animal_sexo').value = selectedAnimal.sexo === 'M' ? 'Macho' : 'Hembra';
                }
            });

            // Agregar un evento de envío del formulario
            document.getElementById('solicitudForm').onsubmit = function(event) {
                event.preventDefault(); // Evitar el envío del formulario por defecto

                // Mostrar una alerta de éxito
                alert('Tu solicitud ha sido enviada con éxito.');

                // Después de la alerta, enviar el formulario
                this.submit('../usuario/index.html'); 
            }
        </script>
    </section>
    <br>
    <br>

    <footer class="footer">
        <div class="footer-section logo">
            <img src="../img/Logo_con_letras-removebg-preview.png" alt="Logo" class="logo-img">
        </div>
        <div class="copyright">
            <p>Proyecto de Adopción y Bienestar Animal Together Pets &copy; 2024</p>
        </div>
    </footer>

    <script src="../js/filtronoticias.js"></script>
</body>
</html>
