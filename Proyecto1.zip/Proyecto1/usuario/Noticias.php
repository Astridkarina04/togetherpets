<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-UA-Compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <title>complete responsive mark express</title>
    <link rel="stylesheet" href="../css/Noticiasf.css">
</head>
<body>
    <header class="header">
        <div class="logo">
            <img src="../img/Logo_con_letras-removebg-preview.png" alt="logo de la marca">
        </div>
        <nav>
            <ul class="nav-links">
                <li><a class="active" href="../usuario/index.php">Inicio</a></li>
                <li><a href="../usuario/peluditos.php">Peluditos</a></li>
                <li><a href="../usuario/Noticias.php">Noticias</a></li>
                <li><a href="../usuario/comoadoptar.html">¿Cómo adoptar?</a></li>
            </ul>
        </nav>
        <div class="header-actions">
            <div class="profile-menu">
                <span class="profile-name">Astrid Karina</span>
                <img src="../img/Nina.PNG" alt="Perfil" class="profile-img">
                <div class="dropdown-content">
                    <a href="../Vista/exito.php">Perfil</a>
                    <a href="../vista/logout.php">Cerrar sesión</a>
                </div>
            </div>
        </div>        
    </header>
    <!-- SCRIPT FOTO DE PERFIL -->
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const profileMenu = document.querySelector('.profile-menu');
            const dropdownContent = document.querySelector('.dropdown-content');
    
            // Verificar si los elementos existen
            if (profileMenu && dropdownContent) {
                profileMenu.addEventListener('click', function(event) {
                    // Evitar que el evento de clic se propague a otros elementos
                    event.stopPropagation();
                    
                    // Toggle entre mostrar y ocultar el menú
                    if (dropdownContent.style.display === 'block') {
                        dropdownContent.style.display = 'none';
                    } else {
                        dropdownContent.style.display = 'block';
                    }
                });
    
                // Ocultar el menú si se hace clic fuera de él
                document.addEventListener('click', function(event) {
                    if (!profileMenu.contains(event.target) && !dropdownContent.contains(event.target)) {
                        dropdownContent.style.display = 'none';
                    }
                });
            }
        });
    </script>
    <!-- SECCIÓN DE NOTICIAS -->
    <div class="container">
        <h1>NOTICIAS MAS RECIENTES</h1>
        <header class="news-header">
            <nav class="categories">
                <span class="cat" onclick="buscar('todos')">Todo</span>
                <span class="cat" onclick="buscar('mascotaP')">Mascotas perdidas</span>
                <span class="cat" onclick="buscar('mascotaE')">Mascotas encontradas</span>
                <span class="cat" onclick="buscar('rescates')">Rescates</span>
                <span class="cat" onclick="buscar('educación')">Historias</span>
            </nav>
            <div class="search-bar">
                <input type="text" placeholder="Qué desea buscar" id="busqueda">
                <button onclick="buscarTema()">Buscar</button>
            </div>
        </header>
        
        <div class="container-card">
            <div class="card">
                <figure>
                    <img src="../img/Noticias/not4.jpg" alt="rescates">
                </figure>
                <div class="contenido-card">
                    <h3>¡Gato Atropellado se Recupera Gracias a una Compleja Cirugía!</h3>
                    <p>Nos alegra informar que el valiente gatito, que fue atropellado en una calle de la ciudad, está en proceso de recuperación tras una cirugía exitosa realizada por el equipo veterinario de Together Pets.</p>
                    <a href="../Vista/noti1.html">Leer más</a>

                </div>
            </div>
            <div class="card">
                <figure>
                    <img src="../img/Noticias/not10.webp" alt="mascotaE">
                </figure>
                <div class="contenido-card">
                    <h3>¡Perro Perdido Reencuentra a Su Familia Después de Dos Años!</h3>
                    <p>Nos llena de alegría compartir la emotiva historia del reencuentro de un perro perdido con su familia después de dos años. Together Pets tuvo el honor de ser parte de este conmovedor momento.</p>
                    <a href="#">Leer más</a>
                </div>
            </div>
            <div class="card">
                <figure>
                    <img src="../img/Noticias/not11.jfif" alt="mascotaP">
                </figure>
                <div class="contenido-card">
                    <h3>!Perro perdido por los lados de la plaza de paloquemado¡</h3>
                    <p>Alaska una perrita criolla se perdio el pasado dia 10 de agosto por la paza de paloquemado cualquier informacion comicarse a los siguientes numeros...</p>
                    <a href="#">Leer más</a>
                </div>
            </div>
            <div class="card">
                <figure>
                    <img src="../img/Noticias/not12.png" alt="educación">
                </figure>
                <div class="contenido-card">
                    <h3>¡Veterinario Viaja a Zonas Rurales para Brindar Atención Gratuita a Animales!</h3>
                    <p>En una destacada iniciativa para apoyar a comunidades rurales, Together Pets ha enviado a un veterinario experimentado para proporcionar atención médica gratuita a animales en zonas alejadas.</p>
                    <a href="#">Leer más</a>
                </div>
            </div>
            <div class="card">
                <figure>
                    <img src="../img/Noticias/not7.jpg" alt="educación">
                </figure>
                <div class="contenido-card">
                    <h3>¡Veterinarios en Acción: Operación Gratuita para Mascotas de Familias de Bajos Recursos!</h3>
                    <p>Nos complace anunciar que Together Pets, en colaboración con un grupo de veterinarios voluntarios, ha llevado a cabo una operación gratuita para mascotas de familias de bajos recursos. Este evento ha brindado cuidados veterinarios esenciales a muchas mascotas que de otro modo no podrían haber recibido tratamient.</p>
                    <a href="#">Leer más</a>
                </div>
            </div>
        </div>
    </div>
        <!-- Botón flotante -->
    <a href="../Vista/creacionNoticiasu.html" class="floating-btn" title="Crear">
        +
    </a>
    <!-- PIE DE PÁGINA -->
    <footer class="footer">
        <div class="footer-section logo">
            <img src="../img/Logo_con_letras-removebg-preview.png" alt="Logo" class="logo-img">
        </div>
        <div class="copyright">
            <p>Proyecto de Adopción y Bienestar Animal Together Pets &copy; 2024</p>
        </div>
    </footer>
    <script src="../js/filtronoticias.js"></script>
</body>
</html>
