<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Perfil de Usuario - Peluditos con Futuro</title>
    <link rel="stylesheet" href="../css/peluditosf.css">
</head>
<body>
    <header class="header">
        <div class="logo">
            <img src="../img/Logo_con_letras-removebg-preview.png" alt="logo de la marca">
        </div>
        <nav>
        <ul class="nav-links">
                <li><a class="active" href="../usuario/index.php">Inicio</a></li>
                <li><a href="../usuario/peluditos.php">Peluditos</a></li>
                <li><a href="../usuario/Noticias.php">Noticias</a></li>
                <li><a href="../usuario/comoadoptar.html">¿Cómo adoptar?</a></li>
         </ul>
        </nav>
        <div class="header-actions">
            <div class="profile-menu">
                <span class="profile-name">Astrid Karina</span>
                <img src="../img/Nina.PNG" alt="Perfil" class="profile-img">
                <div class="dropdown-content">
                    <a href="../Vista/exito.php">Perfil</a>
                    <a href="../vista/logout.php">Cerrar sesión</a>
                </div>
            </div>
        </div>        
    </header>
    <!-- SCRIPT FOTO DE PERFIL -->
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const profileMenu = document.querySelector('.profile-menu');
            const dropdownContent = document.querySelector('.dropdown-content');
    
            // Verificar si los elementos existen
            if (profileMenu && dropdownContent) {
                profileMenu.addEventListener('click', function(event) {
                    // Evitar que el evento de clic se propague a otros elementos
                    event.stopPropagation();
                    
                    // Toggle entre mostrar y ocultar el menú
                    if (dropdownContent.style.display === 'block') {
                        dropdownContent.style.display = 'none';
                    } else {
                        dropdownContent.style.display = 'block';
                    }
                });
    
                // Ocultar el menú si se hace clic fuera de él
                document.addEventListener('click', function(event) {
                    if (!profileMenu.contains(event.target) && !dropdownContent.contains(event.target)) {
                        dropdownContent.style.display = 'none';
                    }
                });
            }
        });
    </script>
    <div class="wrapper">
        <header class="header-mobile">
            <h1 class="logo">CarpiShop</h1>
            <button class="open-menu" id="open-menu">
                <i class="bi bi-list"></i>
            </button>
        </header>
        <aside>

            <header>
                <h1 class="logo">Adopta a tu próximo Amigo...</h1>
            </header>
            <nav>
                <ul class="menu">
                    <li>
                        <button id="todos" class="boton-menu boton-categoria active"><i class="bi bi-hand-index-thumb-fill"></i> Todos</button>
                    </li>
                    <li>
                        <button id="perros" class="boton-menu boton-categoria"><i class="bi bi-hand-index-thumb"></i> Perros</button>
                    </li>
                    <li>
                        <button id="gatos" class="boton-menu boton-categoria"><i class="bi bi-hand-index-thumb"></i> Gatos</button>
                    </li>
                </ul>
                
            </nav>
            <footer>
                <p class="texto-footer">© 2022 Carpi Coder</p>
            </footer>
        </aside>
        <main>
            <!-- Filtros -->
            <div class="filtros">
                <label for="filtro-tamano">Tamaño:</label>
                <select id="filtro-tamano">
                    <option value="todos">Todos</option>
                    <option value="grande">Grande</option>
                    <option value="mediano">Mediano</option>
                    <option value="pequeno">Pequeño</option>
                </select>

                <label for="filtro-sexo">Sexo:</label>
                <select id="filtro-sexo">
                    <option value="todos">Todos</option>
                    <option value="hembra">Hembra</option>
                    <option value="macho">Macho</option>
                </select>
            </div>

            <div id="contenedor-productos" class="contenedor-productos">
                <!-- GATOS -->
                <div class="producto" data-tamano="grande" data-sexo="macho" data-tipo="gatos">
                    <img src="../img/g1.png" alt="Arlequin">
                    <a href="../adopcion/adu1.html" class="enlace-animal">Arlequin</a>
                </div>
                <div class="producto" data-tamano="grande" data-sexo="macho" data-tipo="gatos">
                    <img src="../img/g2.jpg" alt="Alex">
                    <a href="../adopcionadu2.html" class="enlace-animal">Alex</a>
                </div>
                <div class="producto" data-tamano="grande" data-sexo="hembra" data-tipo="gatos">
                    <img src="../img/g3.jpeg" alt="Bibi">
                    <a href="../adopcion/adu3.html" class="enlace-animal">Bibi</a>
                </div>
                <div class="producto" data-tamano="grande" data-sexo="macho" data-tipo="gatos">
                    <img src="../img/g4.jpeg" alt="Casper">
                    <a href="../adopcion/adu4.html" class="enlace-animal">Casper</a>
                </div>
                <div class="producto" data-tamano="grande" data-sexo="macho" data-tipo="gatos">
                    <img src="../img/g5.jpeg" alt="Chocolate">
                    <a href="../adopcion/adu5.html" class="enlace-animal">Chocolate</a>
                </div>
                <div class="producto" data-tamano="grande" data-sexo="hembra" data-tipo="gatos">
                    <img src="../img/g6.jpeg" alt="Flor">
                    <a href="../adopcion/adu6.html" class="enlace-animal">Flor</a>
                </div>
                <div class="producto" data-tamano="grande" data-sexo="hembra" data-tipo="gatos">
                    <img src="../img/g7.jpeg" alt="Lulu">
                    <a href="../adopcion/adu7.html" class="enlace-animal">Lulu</a>
                </div>
                <div class="producto" data-sexo="hembra" data-tipo="gatos">
                    <img src="../img/g8.jpeg" alt="Marina">
                    <a href="../adopcion/adu8.html" class="enlace-animal">Marina</a>
                </div>
                <!-- PERROS -->
                <div class="producto" data-tamano="grande" data-sexo="macho" data-tipo="perros">
                    <img src="../img/pe1.jpeg" alt="Ragna">
                    <a href="../adopcion/adu9.html" class="enlace-animal">Ragna</a>
                </div>
                <div class="producto" data-tamano="mediano" data-sexo="macho" data-tipo="perros">
                    <img src="../img/pe2.jpg" alt="Tuso">
                    <a href="../adopcion/adu10.html" class="enlace-animal">Tuso</a>
                </div>
                <div class="producto" data-tamano="pequeno" data-sexo="macho" data-tipo="perros">
                    <img src="../img/pe3.jpeg" alt="Leo">
                    <a href="../adopcion/adu11.html" class="enlace-animal">Leo</a>
                </div>
                <div class="producto" data-tamano="mediano" data-sexo="macho" data-tipo="perros">
                    <img src="../img/pe4.jpeg" alt="Gus">
                    <a href="../adopcion/adu12.html" class="enlace-animal">Gus</a>
                </div>
                <div class="producto" data-tamano="pequeno" data-sexo="hembra" data-tipo="perros">
                    <img src="../img/pe5.jpeg" alt="Nana">
                    <a href="../adopcion/adu13.html" class="enlace-animal">Nana</a>
                </div>
                <div class="producto" data-tamano="grande" data-sexo="hembra" data-tipo="perros">
                    <img src="../img/pe6.jpg" alt="Coral">
                    <a href="../adopcion/adu14.html" class="enlace-animal">Coral</a>
                </div>
                <div class="producto" data-tamano="mediano" data-sexo="hembra" data-tipo="perros">
                    <img src="../img/pe7.jpeg" alt="Kuka">
                    <a href="../adopcion/adu15.html" class="enlace-animal">Kuka</a>
                </div>
                <div class="producto" data-tamano="grande" data-sexo="hembra" data-tipo="perros">
                    <img src="../img/pe8.jpg" alt="Lexi">
                    <a href="../adopcion/adu16.html" class="enlace-animal">Lexi</a>
                </div>
            </div>
        </main>
    </div>
    <footer class="footer">
        <div class="container container-footer">
            <div class="footer-section logo">
                <img src="../img/Logo_con_letras-removebg-preview.png" alt="Logo" class="logo-img">
            </div>
        </div>
        <br>
        <div class="copyright">
            <p>Proyecto de Adopción y Bienestar Animal Together Pets &copy; 2024</p>
        </div>
    </footer>
    
    <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/toastify-js"></script>
    <script src="../js/main.js"></script>
</body>
</html>
