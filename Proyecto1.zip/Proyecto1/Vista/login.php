<?php
session_start();
include 'conexion.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $correo = $_POST['correo'];
    $contrasena = $_POST['contrasena'];

    $sql = "SELECT * FROM usuarios WHERE correo='$correo'";
    $resultado = $conn->query($sql);

    if ($resultado->num_rows > 0) {
        $fila = $resultado->fetch_assoc();
        // Comparar la contraseña ingresada con la almacenada en texto plano
        if ($contrasena === $fila['contrasena']) {
            // Almacena los datos del usuario en la sesión
            $_SESSION['usuario'] = $fila;
            header("Location: exito.php"); // Redirige a la página de éxito
            exit();
        } else {
            echo "<script>alert('Contraseña incorrecta'); window.location.href='login.php';</script>";
        }
    } else {
        echo "<script>alert('No se encontró el usuario'); window.location.href='login.php';</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="x-UA-Compatible" content="ie=edge">
	<meta name="viewport" content="width=device-width,initial-scale=1.0">
	<title>complete responsive mark express</title>
	<link rel="stylesheet" href="../css/login.css">
</head>
<body>

	<header class="header"><!-- barra de tarea -->
	  	<div class="logo">
			<img src="../img/Logo_con_letras-removebg-preview.png" alt="logo de la marca" href="../Index.html"></img>
	  	</div>
	  	<nav>
			<ul class="nav-links">
				<li><a class="active" href="../Index.html">Inicio</a></li>
				<li><a href="peluditos.php">Peluditos </a></li>
				<li><a href="noticias.php">Noticias </a></li>
				<li><a href="comoadoptar.html">¿Como Adoptar?</a></li>
				
			</ul>
		</nav>
		<div>
			<a href='../Vista/registro.php' class="btn"><button>Registrarse</button></a>
		</div>
	</header>
    <br>
    <br>
	<div class="wrapper">
		<div class="form-box">
			<div class="login-container" id="login">
				<header>Iniciar sesión</header>
				<form action="login.php" method="POST">
					<div class="input-box">
						Correo<input type="email" id="correo" name="correo" class="input-field" placeholder="usuario@ejemplo.com" required>
					</div>
					<div class="input-box">
						Contraseña<input type="password" id="contrasena" name="contrasena" class="input-field" placeholder="********" required>
					</div>
					<div class="two-col">
						<div class="one">
							<input type="checkbox" id="recordar" name="recordar">
							<label for="recordar">Recordar</label>
						</div>
						<div class="two">
							<label><a href="#" id="setTex">¿Olvidaste tu contraseña?</a></label>
						</div>
					</div>
					<div class="input-box">
						<button type="submit" class="submit">Iniciar</button>
					</div>
				</form>
				<div class="top login-link">
					<span>¿Aún no tienes cuenta? <a href="../Vista/registro.php">Registrar</a></span>
				</div>
			</div>
		</div>
		<!-- Espaciador adicional -->
		<div class="extra-space"></div>
	</div>
</body>	
</html>