<?php
$host = 'localhost';
$usuario = 'root';
$contrasena = '';
$nombre_bd = 'mi_base_de_datos';


$conn = new mysqli($host, $usuario, $contrasena, $nombre_bd);

if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}





