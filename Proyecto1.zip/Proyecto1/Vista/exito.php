<?php
session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}

$usuario = $_SESSION['usuario'];
$imagePath = isset($_SESSION['image']) ? $_SESSION['image'] : ''; // Ruta de la imagen de perfil
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Perfil de Usuario</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/perfil.css">
</head>
<body>
    <header class="header">
        <div class="logo">
            <img src="../img/Logo_con_letras-removebg-preview.png" alt="Logo de la marca">
        </div>
        <nav>
            <ul class="nav-links">
                <li><a class="active" href="../usuario/index.php">Inicio</a></li>
                <li><a href="../usuario/peluditos.php">Peluditos</a></li>
                <li><a href="../usuario/Noticias.php">Noticias</a></li>
                <li><a href="../usuario/comoadoptar.html">¿Cómo adoptar?</a></li>
            </ul>
        </nav>
        <div class="header-actions">
            <div class="profile-menu">
                <span class="profile-name" id="header-profile-name">Astrid Karina</span>
                <img src="../img/Nina.PNG" alt="Perfil" class="profile-img" id="header-profile-img">
                <div class="dropdown-content">
                    <a href="../Vista/perfilu.html">Perfil</a>
                    <a href="../Index.html">Cerrar sesión</a>
                </div>
            </div>
        </div>
        
    </header>
    
    <section>
        <div class="profile-container">
            <!-- Barra lateral (Aside) -->
            <aside class="profile-sidebar">
            
                <!-- Imagen de perfil -->
                <div class="profile-photo">
                    <?php if ($imagePath): ?>
                        <img id="uploadedImage" src="<?php echo $imagePath; ?>" alt="Imagen de Perfil" />
                    <?php endif; ?>
                </div>
                <div class="profile-info">
                    <h1><?php echo $usuario['nombre'] . " " . $usuario['apellido']; ?></h1>
                    <p><i class="fas fa-map-marker-alt"></i> <?php echo $usuario['direccion']; ?></p> <!-- Ícono de dirección -->
                    <p><i class="fas fa-phone-alt"></i> <?php echo $usuario['telefono']; ?></p> <!-- Ícono de teléfono -->
                    <p><i class="fas fa-envelope"></i> <?php echo $usuario['correo']; ?></p> <!-- Ícono de correo -->
                </div>

                <!-- Formulario para subir imagen (solo botones y campo de archivo debajo) -->
                <form class="profile-photo" id="uploadForm" enctype="multipart/form-data" method="POST" action="upload.php">
                    <input type="file" id="imageInput" name="image" accept="image/*" />
                    <button type="submit" id="saveButton">Guardar Imagen</button>
                </form>
                <a href="logout.php" class="logout-link">Cerrar sesión</a>

            </aside>

            <!-- Contenedor principal de publicaciones -->
            <main class="profile-main">
                <div class="welcome-message">
                    <h2>Bienvenido a tu perfil, <?php echo $usuario['nombre'] . " " . $usuario['apellido']; ?></h2>
                    <p>Es un placer tenerte en ToguterPets. Aquí puedes encontrar a tu próximo amigo o ayudar a una Huella amiga.</p>
                </div>

                <div class="user-posts">
                    <h2>Publicaciones</h2>
                    <div class="posts-container">
                        <div class="post-card">
                            <h3>Nuevo Publicacion</h3>
                            <p>Crea tu primera Publicacion</p>
                            <div class="post-actions">
                                <button class="edit-post-btn">Editar</button>
                                <button class="delete-post-btn">Eliminar</button>
                            </div>
                        </div>
                        <div class="post-card">
                            <h3>Nueva Publicacion</h3>
                            <p>Di lo que piensas</p>
                            <div class="post-actions">
                                <button class="edit-post-btn">Editar</button>
                                <button class="delete-post-btn">Eliminar</button>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </section>
</body>


    <script>
        // Manejador de vista previa de la imagen seleccionada
        document.getElementById('imageInput').addEventListener('change', function(event) {
            const file = event.target.files[0];
            const reader = new FileReader();
            
            reader.onload = function(e) {
                const preview = document.getElementById('uploadedImage');
                if (preview) {
                    preview.src = e.target.result; // Muestra la vista previa de la imagen
                }
            };
            
            reader.readAsDataURL(file);
        });
    </script>
</body>
</html>
